import C1 from "./harp/C1.mp3";
import Db1 from "./harp/Db1.mp3";
import D1 from "./harp/D1.mp3";
import Eb1 from "./harp/Eb1.mp3";
import E1 from "./harp/E1.mp3";
import F1 from "./harp/F1.mp3";
import Gb1 from "./harp/Gb1.mp3";
import G1 from "./harp/G1.mp3";
import Ab1 from "./harp/Ab1.mp3";
import A1 from "./harp/A1.mp3";
import Bb1 from "./harp/Bb1.mp3";
import B1 from "./harp/B1.mp3";
import C2 from "./harp/C2.mp3";
import Db2 from "./harp/Db2.mp3";
import D2 from "./harp/D2.mp3";
import Eb2 from "./harp/Eb2.mp3";
import E2 from "./harp/E2.mp3";
import F2 from "./harp/F2.mp3";
import Gb2 from "./harp/Gb2.mp3";
import G2 from "./harp/G2.mp3";
import Ab2 from "./harp/Ab2.mp3";
import A2 from "./harp/A2.mp3";
import Bb2 from "./harp/Bb2.mp3";
import B2 from "./harp/B2.mp3";
import C3 from "./harp/C3.mp3";
import Db3 from "./harp/Db3.mp3";
import D3 from "./harp/D3.mp3";
import Eb3 from "./harp/Eb3.mp3";
import E3 from "./harp/E3.mp3";
import F3 from "./harp/F3.mp3";
import Gb3 from "./harp/Gb3.mp3";
import G3 from "./harp/G3.mp3";
import Ab3 from "./harp/Ab3.mp3";
import A3 from "./harp/A3.mp3";
import Bb3 from "./harp/Bb3.mp3";
import B3 from "./harp/B3.mp3";
import C4 from "./harp/C4.mp3";
import Db4 from "./harp/Db4.mp3";
import D4 from "./harp/D4.mp3";
import Eb4 from "./harp/Eb4.mp3";
import E4 from "./harp/E4.mp3";
import F4 from "./harp/F4.mp3";
import Gb4 from "./harp/Gb4.mp3";
import G4 from "./harp/G4.mp3";
import Ab4 from "./harp/Ab4.mp3";
import A4 from "./harp/A4.mp3";
import Bb4 from "./harp/Bb4.mp3";
import B4 from "./harp/B4.mp3";
import C5 from "./harp/C5.mp3";
import Db5 from "./harp/Db5.mp3";
import D5 from "./harp/D5.mp3";
import Eb5 from "./harp/Eb5.mp3";
import E5 from "./harp/E5.mp3";
import F5 from "./harp/F5.mp3";
import Gb5 from "./harp/Gb5.mp3";
import G5 from "./harp/G5.mp3";
import Ab5 from "./harp/Ab5.mp3";
import A5 from "./harp/A5.mp3";
import Bb5 from "./harp/Bb5.mp3";
import B5 from "./harp/B5.mp3";
import C6 from "./harp/C6.mp3";
import Db6 from "./harp/Db6.mp3";
import D6 from "./harp/D6.mp3";
import Eb6 from "./harp/Eb6.mp3";
import E6 from "./harp/E6.mp3";
import F6 from "./harp/F6.mp3";
import Gb6 from "./harp/Gb6.mp3";
import G6 from "./harp/G6.mp3";
import Ab6 from "./harp/Ab6.mp3";
import A6 from "./harp/A6.mp3";
import Bb6 from "./harp/Bb6.mp3";
import B6 from "./harp/B6.mp3";
import C7 from "./harp/C7.mp3";
import Db7 from "./harp/Db7.mp3";
import D7 from "./harp/D7.mp3";
import Eb7 from "./harp/Eb7.mp3";
import E7 from "./harp/E7.mp3";
import F7 from "./harp/F7.mp3";
import Gb7 from "./harp/Gb7.mp3";
import G7 from "./harp/G7.mp3";
import Ab7 from "./harp/Ab7.mp3";
import A7 from "./harp/A7.mp3";
import Bb7 from "./harp/Bb7.mp3";

export const harp = [
    C1,
    Db1,
    D1,
    Eb1,
    E1,
    F1,
    Gb1,
    G1,
    Ab1,
    A1,
    Bb1,
    B1,
    C2,
    Db2,
    D2,
    Eb2,
    E2,
    F2,
    Gb2,
    G2,
    Ab2,
    A2,
    Bb2,
    B2,
    C3,
    Db3,
    D3,
    Eb3,
    E3,
    F3,
    Gb3,
    G3,
    Ab3,
    A3,
    Bb3,
    B3,
    C4,
    Db4,
    D4,
    Eb4,
    E4,
    F4,
    Gb4,
    G4,
    Ab4,
    A4,
    Bb4,
    B4,
    C5,
    Db5,
    D5,
    Eb5,
    E5,
    F5,
    Gb5,
    G5,
    Ab5,
    A5,
    Bb5,
    B5,
    C6,
    Db6,
    D6,
    Eb6,
    E6,
    F6,
    Gb6,
    G6,
    Ab6,
    A6,
    Bb6,
    B6,
    C7,
    Db7,
    D7,
    Eb7,
    E7,
    F7,
    Gb7,
    G7,
    Ab7,
    A7,
    Bb7,
];