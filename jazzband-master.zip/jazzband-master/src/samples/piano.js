import C1 from "./piano/C1.mp3";
import Db1 from "./piano/Db1.mp3";
import D1 from "./piano/D1.mp3";
import Eb1 from "./piano/Eb1.mp3";
import E1 from "./piano/E1.mp3";
import F1 from "./piano/F1.mp3";
import Gb1 from "./piano/Gb1.mp3";
import G1 from "./piano/G1.mp3";
import Ab1 from "./piano/Ab1.mp3";
import A1 from "./piano/A1.mp3";
import Bb1 from "./piano/Bb1.mp3";
import B1 from "./piano/B1.mp3";
import C2 from "./piano/C2.mp3";
import Db2 from "./piano/Db2.mp3";
import D2 from "./piano/D2.mp3";
import Eb2 from "./piano/Eb2.mp3";
import E2 from "./piano/E2.mp3";
import F2 from "./piano/F2.mp3";
import Gb2 from "./piano/Gb2.mp3";
import G2 from "./piano/G2.mp3";
import Ab2 from "./piano/Ab2.mp3";
import A2 from "./piano/A2.mp3";
import Bb2 from "./piano/Bb2.mp3";
import B2 from "./piano/B2.mp3";
import C3 from "./piano/C3.mp3";
import Db3 from "./piano/Db3.mp3";
import D3 from "./piano/D3.mp3";
import Eb3 from "./piano/Eb3.mp3";
import E3 from "./piano/E3.mp3";
import F3 from "./piano/F3.mp3";
import Gb3 from "./piano/Gb3.mp3";
import G3 from "./piano/G3.mp3";
import Ab3 from "./piano/Ab3.mp3";
import A3 from "./piano/A3.mp3";
import Bb3 from "./piano/Bb3.mp3";
import B3 from "./piano/B3.mp3";
import C4 from "./piano/C4.mp3";
import Db4 from "./piano/Db4.mp3";
import D4 from "./piano/D4.mp3";
import Eb4 from "./piano/Eb4.mp3";
import E4 from "./piano/E4.mp3";
import F4 from "./piano/F4.mp3";
import Gb4 from "./piano/Gb4.mp3";
import G4 from "./piano/G4.mp3";
import Ab4 from "./piano/Ab4.mp3";
import A4 from "./piano/A4.mp3";
import Bb4 from "./piano/Bb4.mp3";
import B4 from "./piano/B4.mp3";
import C5 from "./piano/C5.mp3";
import Db5 from "./piano/Db5.mp3";
import D5 from "./piano/D5.mp3";
import Eb5 from "./piano/Eb5.mp3";
import E5 from "./piano/E5.mp3";
import F5 from "./piano/F5.mp3";
import Gb5 from "./piano/Gb5.mp3";
import G5 from "./piano/G5.mp3";
import Ab5 from "./piano/Ab5.mp3";
import A5 from "./piano/A5.mp3";
import Bb5 from "./piano/Bb5.mp3";
import B5 from "./piano/B5.mp3";
import C6 from "./piano/C6.mp3";
import Db6 from "./piano/Db6.mp3";
import D6 from "./piano/D6.mp3";
import Eb6 from "./piano/Eb6.mp3";
import E6 from "./piano/E6.mp3";
import F6 from "./piano/F6.mp3";
import Gb6 from "./piano/Gb6.mp3";
import G6 from "./piano/G6.mp3";
import Ab6 from "./piano/Ab6.mp3";
import A6 from "./piano/A6.mp3";
import Bb6 from "./piano/Bb6.mp3";
import B6 from "./piano/B6.mp3";
import C7 from "./piano/C7.mp3";
import Db7 from "./piano/Db7.mp3";
import D7 from "./piano/D7.mp3";
import Eb7 from "./piano/Eb7.mp3";
import E7 from "./piano/E7.mp3";
import F7 from "./piano/F7.mp3";
import Gb7 from "./piano/Gb7.mp3";
import G7 from "./piano/G7.mp3";
import Ab7 from "./piano/Ab7.mp3";
import A7 from "./piano/A7.mp3";
import Bb7 from "./piano/Bb7.mp3";
import B7 from "./piano/B7.mp3";

export const piano = [
    C1,
    Db1,
    D1,
    Eb1,
    E1,
    F1,
    Gb1,
    G1,
    Ab1,
    A1,
    Bb1,
    B1,
    C2,
    Db2,
    D2,
    Eb2,
    E2,
    F2,
    Gb2,
    G2,
    Ab2,
    A2,
    Bb2,
    B2,
    C3,
    Db3,
    D3,
    Eb3,
    E3,
    F3,
    Gb3,
    G3,
    Ab3,
    A3,
    Bb3,
    B3,
    C4,
    Db4,
    D4,
    Eb4,
    E4,
    F4,
    Gb4,
    G4,
    Ab4,
    A4,
    Bb4,
    B4,
    C5,
    Db5,
    D5,
    Eb5,
    E5,
    F5,
    Gb5,
    G5,
    Ab5,
    A5,
    Bb5,
    B5,
    C6,
    Db6,
    D6,
    Eb6,
    E6,
    F6,
    Gb6,
    G6,
    Ab6,
    A6,
    Bb6,
    B6,
    C7,
    Db7,
    D7,
    Eb7,
    E7,
    F7,
    Gb7,
    G7,
    Ab7,
    A7,
    Bb7,
    B7,
];