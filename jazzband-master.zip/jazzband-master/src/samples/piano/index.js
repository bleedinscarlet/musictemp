import C1 from "./C1.mp3";
import Db1 from "./Db1.mp3";
import D1 from "./D1.mp3";
import Eb1 from "./Eb1.mp3";
import E1 from "./E1.mp3";
import F1 from "./F1.mp3";
import Gb1 from "./Gb1.mp3";
import G1 from "./G1.mp3";
import Ab1 from "./Ab1.mp3";
import A1 from "./A1.mp3";
import Bb1 from "./Bb1.mp3";
import B1 from "./B1.mp3";
import C2 from "./C2.mp3";
import Db2 from "./Db2.mp3";
import D2 from "./D2.mp3";
import Eb2 from "./Eb2.mp3";
import E2 from "./E2.mp3";
import F2 from "./F2.mp3";
import Gb2 from "./Gb2.mp3";
import G2 from "./G2.mp3";
import Ab2 from "./Ab2.mp3";
import A2 from "./A2.mp3";
import Bb2 from "./Bb2.mp3";
import B2 from "./B2.mp3";
import C3 from "./C3.mp3";
import Db3 from "./Db3.mp3";
import D3 from "./D3.mp3";
import Eb3 from "./Eb3.mp3";
import E3 from "./E3.mp3";
import F3 from "./F3.mp3";
import Gb3 from "./Gb3.mp3";
import G3 from "./G3.mp3";
import Ab3 from "./Ab3.mp3";
import A3 from "./A3.mp3";
import Bb3 from "./Bb3.mp3";
import B3 from "./B3.mp3";
import C4 from "./C4.mp3";
import Db4 from "./Db4.mp3";
import D4 from "./D4.mp3";
import Eb4 from "./Eb4.mp3";
import E4 from "./E4.mp3";
import F4 from "./F4.mp3";
import Gb4 from "./Gb4.mp3";
import G4 from "./G4.mp3";
import Ab4 from "./Ab4.mp3";
import A4 from "./A4.mp3";
import Bb4 from "./Bb4.mp3";
import B4 from "./B4.mp3";
import C5 from "./C5.mp3";
import Db5 from "./Db5.mp3";
import D5 from "./D5.mp3";
import Eb5 from "./Eb5.mp3";
import E5 from "./E5.mp3";
import F5 from "./F5.mp3";
import Gb5 from "./Gb5.mp3";
import G5 from "./G5.mp3";
import Ab5 from "./Ab5.mp3";
import A5 from "./A5.mp3";
import Bb5 from "./Bb5.mp3";
import B5 from "./B5.mp3";
import C6 from "./C6.mp3";
import Db6 from "./Db6.mp3";
import D6 from "./D6.mp3";
import Eb6 from "./Eb6.mp3";
import E6 from "./E6.mp3";
import F6 from "./F6.mp3";
import Gb6 from "./Gb6.mp3";
import G6 from "./G6.mp3";
import Ab6 from "./Ab6.mp3";
import A6 from "./A6.mp3";
import Bb6 from "./Bb6.mp3";
import B6 from "./B6.mp3";
import C7 from "./C7.mp3";
import Db7 from "./Db7.mp3";
import D7 from "./D7.mp3";
import Eb7 from "./Eb7.mp3";
import E7 from "./E7.mp3";
import F7 from "./F7.mp3";
import Gb7 from "./Gb7.mp3";
import G7 from "./G7.mp3";
import Ab7 from "./Ab7.mp3";
import A7 from "./A7.mp3";
import Bb7 from "./Bb7.mp3";
import B7 from "./B7.mp3";

export const piano = {
    C1,
    Db1,
    D1,
    Eb1,
    E1,
    F1,
    Gb1,
    G1,
    Ab1,
    A1,
    Bb1,
    B1,
    C2,
    Db2,
    D2,
    Eb2,
    E2,
    F2,
    Gb2,
    G2,
    Ab2,
    A2,
    Bb2,
    B2,
    C3,
    Db3,
    D3,
    Eb3,
    E3,
    F3,
    Gb3,
    G3,
    Ab3,
    A3,
    Bb3,
    B3,
    C4,
    Db4,
    D4,
    Eb4,
    E4,
    F4,
    Gb4,
    G4,
    Ab4,
    A4,
    Bb4,
    B4,
    C5,
    Db5,
    D5,
    Eb5,
    E5,
    F5,
    Gb5,
    G5,
    Ab5,
    A5,
    Bb5,
    B5,
    C6,
    Db6,
    D6,
    Eb6,
    E6,
    F6,
    Gb6,
    G6,
    Ab6,
    A6,
    Bb6,
    B6,
    C7,
    Db7,
    D7,
    Eb7,
    E7,
    F7,
    Gb7,
    G7,
    Ab7,
    A7,
    Bb7,
    B7,
};