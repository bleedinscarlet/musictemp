import { piano } from './piano';
import { drumset } from './drumset';
import { metronome } from './metronome';

export const samples = { piano, drumset, metronome };