
import m from './metronome.wav';

export const metronome = m;