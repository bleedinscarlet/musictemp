declare module 'waaclock';
declare module 'tonal';