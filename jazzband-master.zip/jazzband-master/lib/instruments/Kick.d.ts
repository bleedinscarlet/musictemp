export declare class Kick {
    osc: any;
    context: any;
    gain: any;
    constructor(context: any);
    setup(): void;
    trigger(time: any): void;
}
