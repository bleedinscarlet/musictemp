export declare const funk: {
    name: string;
    tempo: number;
    chords: () => any;
    bass: () => any;
    kick: (t: any) => (number | number[])[][];
    snare: (t: any) => (number | number[])[];
    hihat: (t: any) => number[][];
};
