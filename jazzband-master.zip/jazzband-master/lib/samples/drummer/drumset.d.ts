export declare const kick: any;
export declare const snare: any;
export declare const hihat: any;
export declare const ride: any;
export declare const crash: any;
export declare const rimshot: any;
export declare const drumset: any[];
export declare const drumSamples: {
    'C1': any;
    'C2': any;
    'C3': any;
    'C4': any;
    'C5': any;
    'C6': any;
};
